<?php
if (!defined('IN_FINECMS')) exit('');

/*
 * 创建会用到的数据表
 */

return array(
	//"DROP TABLE IF EXISTS `{prefix}yuedu`;",	//
);