<?php
if (!defined('IN_FINECMS')) exit('');

/*
 * ɾ�����ݱ�
 */

return array(
    //"DROP TABLE IF EXISTS `{prefix}yuedu`;",
);