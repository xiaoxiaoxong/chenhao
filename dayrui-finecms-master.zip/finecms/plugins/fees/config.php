<?php
if (!defined('IN_FINECMS')) exit('');

return array(
    'name'			=> '投稿收费',	//插件的中文名称
    'typeid'		=> 1,	//插件类别,1为内置控制器,2为嵌入式插件
    'fields'		=> array(),	//配置文件的字段格式
    'author'		=> 'dayrui',	//插件作者
    'version'		=> '1.0',	//插件版本号
    'description'	=> '顾名思义，该插件功能就是会员必须支付一定的费用才能投稿，需要配合“在线充值”插件'	//插件描述信息
);