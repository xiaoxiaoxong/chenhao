<?php
if (!defined('IN_FINECMS')) exit('');

return array(
    'name'			=> '同步分享',	//插件的中文名称
    'typeid'		=> 1,	//插件类别,1为内置控制器,2为嵌入式插件
    'fields'		=> array(),	//配置文件的字段格式
    'author'		=> 'dayrui',	//插件作者
    'version'		=> '1.0',	//插件版本号
    'description'	=> '将投稿同步分享到QQ空间、腾讯微博、新浪微博'	//插件描述信息
);