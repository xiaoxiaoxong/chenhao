<?php

class VoteModel extends Model {
    
	protected function get_primary_key() {
		return $this->primary_key = 'id';
	}
	
}