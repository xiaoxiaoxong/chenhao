<?php

if (!defined('IN_FINECMS')) exit('Vote No permission resources');

return array(
    'name'    => '投票系统',
    'author'  => 'Jesecc',
    'version' => '1.0',
    'typeid'  => 1,
    'description' => '投票调查',
    'fields' => array(
       
    )
);