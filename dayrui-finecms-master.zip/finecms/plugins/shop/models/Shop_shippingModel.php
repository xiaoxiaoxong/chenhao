<?php
class Shop_shippingModel extends Model {
    
	protected function get_primary_key() {
		return $this->primary_key = 'id';
	}
	
}