<?php
if (!defined('IN_FINECMS')) exit('No permission resources');

return array(
    "DROP TABLE IF EXISTS `{prefix}shop_address`;",
    "DROP TABLE IF EXISTS `{prefix}shop_order`;",
    "DROP TABLE IF EXISTS `{prefix}shop_order`;"
);