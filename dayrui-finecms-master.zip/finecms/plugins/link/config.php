<?php
if (!defined('IN_FINECMS')) exit('No permission resources');

return array(
    'name' => '友情链接',
    'author' => 'finecms',
    'version' => '1.2',
    'typeid' => 1,
    'description' => "友情链接使用说明参考论坛",
    'fields' => array(
       
    )
);