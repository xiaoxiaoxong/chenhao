<?php
if (!defined('IN_FINECMS')) exit('No permission resources');

return array(
    
);