<?php
if (!defined('IN_FINECMS')) exit('No permission resources');

return array(
    'name'    => '广告管理',
    'author'  => 'finecms',
    'version' => '1.7',
    'typeid'  => 1,
    'description' => '广告管理系统插件'
);