<?php
if (!defined('IN_FINECMS')) exit('No permission resources');

return array(
    'name'			=> '阅读收费',
    'author'		=> 'dayrui',
    'version'		=> '1.0',
    'typeid'		=> 1,
    'fields'		=> array(),
    'description'	=> '文档内容查看、文件下载、图片查看、联系方式收费服务'
);