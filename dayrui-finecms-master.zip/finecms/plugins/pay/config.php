<?php
if (!defined('IN_FINECMS')) exit('No permission resources');

return array(
    'name'			=> '在线充值',
    'author'		=> 'dayrui',
    'version'		=> '1.3',
    'typeid'		=> 1,
    'fields'		=> array(),
    'description'	=> '提供支付宝、财付通等支付方式,支持生成虚拟充值卡',
);