<?php

return array(

	'name'    => 'FineCMS',
	'version' => '1.7.9',
	'update'  => '2013-11-07',

);